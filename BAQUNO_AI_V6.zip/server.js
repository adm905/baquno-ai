import 'dotenv/config';
import express from 'express';
import multer from 'multer';
import OpenAI, { toFile } from 'openai';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { files: 2, fileSize: 50 * 1024 * 1024 }
});

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const actionText = {
  handshake: 'Have both people naturally shake hands, with realistic anatomy and hands, while preserving their recognizable facial identity and natural appearance.',
  hug: 'Have both people warmly hug each other in a natural, respectful way, preserving their recognizable facial identity and natural appearance.',
  hello: 'Have both people greet each other naturally with a friendly gesture, preserving their recognizable facial identity and natural appearance.',
  memory: 'Create a beautiful realistic commemorative photo of both people together, as if they were photographed together at the same moment, preserving recognizable facial identity.',
  together: 'Place both people naturally standing together as if they were photographed together, preserving recognizable facial identity, body proportions, and natural appearance.'
};

const placeText = {
  auto: 'Choose a tasteful realistic location that suits the people and the requested interaction.',
  beach: 'Place them on a beautiful realistic beach with natural daylight and a cinematic atmosphere.',
  street: 'Place them together on a realistic elegant street scene with natural lighting.',
  luxury: 'Place them in a luxurious elegant location with premium cinematic lighting.',
  studio: 'Place them in a professional photography studio with realistic softbox lighting.'
};

const sizeMap = {
  '1:1': '1024x1024',
  '4:5': '1024x1536',
  '9:16': '1024x1536',
  '16:9': '1536x1024'
};

function cleanChoice(value, allowed, fallback) {
  return allowed.includes(value) ? value : fallback;
}

app.post('/api/mix', upload.array('images', 2), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: 'لم يتم إعداد مفتاح محرك الصور بعد. أضف OPENAI_API_KEY في ملف .env ثم شغّل الخادم.' });
    }
    if (!req.files || req.files.length !== 2) {
      return res.status(400).json({ error: 'ارفع صورتين بالضبط.' });
    }

    const action = cleanChoice(req.body.action, Object.keys(actionText), 'memory');
    const place = cleanChoice(req.body.place, Object.keys(placeText), 'auto');
    const ratio = cleanChoice(req.body.ratio, Object.keys(sizeMap), '1:1');

    const prompt = `Create one photorealistic, coherent image using the two supplied reference images as the identities of the two people. ${actionText[action]} ${placeText[place]} Composition: both people must clearly appear together in the same scene, with consistent perspective, lighting, shadows, scale, skin texture and clothing details. Do not invent a third person. Do not change their identities. Do not add text, logos, captions, borders, or watermarks. ${ratio} aspect-ratio composition.`;

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const imageFiles = await Promise.all(req.files.map((file) =>
      toFile(file.buffer, file.originalname || 'image.png', { type: file.mimetype })
    ));

    const result = await client.images.edit({
      model: 'gpt-image-2.5-sunburst',
      image: imageFiles,
      prompt,
      size: sizeMap[ratio],
      quality: 'low',
      output_format: 'jpeg',
      output_compression: 88
    });

    const b64 = result.data?.[0]?.b64_json;
    if (!b64) throw new Error('لم يرجع محرك الصور صورة صالحة.');

    res.json({ image: `data:image/jpeg;base64,${b64}`, ratio, action, place });
  } catch (error) {
    console.error(error);
    const message = error?.error?.message || error?.message || 'حدث خطأ أثناء إنشاء الصورة.';
    res.status(500).json({ error: message });
  }
});

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`BAQUNO AI running on http://localhost:${port}`));
