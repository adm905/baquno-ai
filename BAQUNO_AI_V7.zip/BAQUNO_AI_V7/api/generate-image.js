import OpenAI from 'openai';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: 'OPENAI_API_KEY is not configured on the server.' });
  try {
    const { image1, image2, action='صورة تذكارية', place='تلقائي', size='1024x1024' } = req.body || {};
    if (!image1 || !image2) return res.status(400).json({ error: 'Please provide two images.' });
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const prompt = `Edit the first reference image using the second reference image as a person reference. Create one natural, photorealistic scene where the two people are together. Action: ${action}. Setting: ${place}. Preserve each person's recognizable facial identity, age, hair, skin tone and natural proportions as much as possible. Do not invent extra people. Make the composition look like a genuine photograph, with coherent lighting, shadows and perspective. This is a benign personal image edit, not intended to deceive or impersonate anyone.`;
    const response = await client.images.edit({
      model: 'gpt-image-2.5-sunburst',
      image: [
        { image_url: image1 },
        { image_url: image2 }
      ],
      prompt,
      size,
      quality: 'low',
      output_format: 'jpeg',
      output_compression: 85
    });
    const b64 = response.data?.[0]?.b64_json;
    if (!b64) return res.status(502).json({ error: 'No image was returned by the image service.' });
    return res.status(200).json({ image: `data:image/jpeg;base64,${b64}` });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: e?.message || 'Image generation failed.' });
  }
}
